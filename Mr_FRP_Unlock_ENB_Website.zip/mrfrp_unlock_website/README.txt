# Mr FRP Unlock – East New Britain website

This is a ready-to-upload static website for GitHub Pages.

## Files
- `index.html` — the website homepage
- `images/` — all 10 promotional images supplied for the website

## Publish with GitHub Pages
1. Open your GitHub repository: `mrfrpunlockenb.github.io`.
2. Upload `index.html` and the complete `images` folder from this ZIP to the repository root.
3. Commit the upload to the `main` branch.
4. In **Settings → Pages**, confirm **Deploy from a branch**, branch `main`, folder `/ (root)`.
5. Wait for GitHub Pages to publish, then open `https://mrfrpunlockenb-create.github.io`.

Do not upload only `index.html`; the `images` folder must be uploaded too.

## Contact details included
- Phone service / remote support WhatsApp: +675 8152 9321
- Tool rental WhatsApp: +675 7301 8665
- Facebook: https://www.facebook.com/profile.php?id=61596136121641

The website presents prices as shown in the supplied posters and advises visitors to confirm availability and compatibility.
